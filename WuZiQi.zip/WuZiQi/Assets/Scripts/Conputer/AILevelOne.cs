﻿using UnityEngine;

public class AILevelOne : AIParent
{
    public override void PlayChest()
    {

    }
}

